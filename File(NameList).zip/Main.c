// CREATING A PROGRAM TO STORE NAMES
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

// NOTES:
	/*
		- ADDED FILE FUNCTIONALITY TO ADD NAMES TO THE FILE
		- ADDED FILE FUNCTIONALITY TO VIEW NAMES ON THE FILE
		- ADDED FILE DELETION FUNCTIONALITY
	*/

int main()
{
	// Basi program variables
	int input = 0;
	int num = 0;
	char name[40];
	int count = 0;
	int delIndex = 0;
	// Name List array
	char ListOfNames[5][40];

	// File handling variables
	char temp = 0;


	do {
		//printf("Enter a number from the options below: \n");
		printf("Name Database options:\n");
		printf("1. Add new names\n");
		printf("2. View name list current session\n");
		printf("3. View name list from saved file\n");
		printf("4. Delete name from list\n");
		printf("5. Quit program\n");
		printf("\nEnter a number from the options above: ");
		scanf_s("%d", &input);
		putchar('\n');
		while (getchar() != '\n');

		switch (input) {
		case 1:
			printf("Add name: ");
			fgets(name, sizeof(name), stdin);
			name[strcspn(name, "\n")] = '\0';
			if (count < 5) {
				strcpy(ListOfNames[count], name);
				count++;
			}
			else if (name[strlen(name) - 1] == '\n') {
				name[strlen(name - 1)] == '\0';
			}
			else {
				printf("\nName list capacity exceeded!");
			}
			// This allows name input to be added to a file
			FILE* fp = fopen("C:\\..\\..\\..\\NameList.txt", "a"); // Please replace with where you want to send the file
			if (fp != NULL) {
				fprintf(fp, "%s\n", name);
				fclose(fp);
			}
			printf("Name Added to file!\n");
			break;
		case 2:
			printf("All names: \n");
			for (int i = 0; i < count; i++)
			{
				num = num + 1;
				printf("#%d: %s\n", i + 1, ListOfNames[i]);
				putchar('\n');
			}
			break;
		case 3:
			fp = fopen("C:\\..\\..\\..\\NameList.txt", "r"); // Please replace with where you want to send the file
			char buffer[1024] = { 0 };
			if (fp == NULL)
			{
				printf("Could not open file!\n");
				return 1;
			}
			while (fgets(buffer, sizeof(buffer), fp) != NULL) {
				printf("%s", buffer);

				putchar('\n');
			}
			break;
		case 4:
			printf("Choose an element from the list to delete (ex. 0-%d): ", count - 1);
			scanf_s("%d", &delIndex);
			while (getchar() != '\n');
			// Check for valid index before attempting deletion
			if (delIndex >= 0 && delIndex < count) {
				for (int i = delIndex; i < count - 1; i++)
				{
					strcpy(ListOfNames[i], ListOfNames[i + 1]);
				}
				ListOfNames[count - 1][0] = '\0';
				count--;

				fp = fopen("C:\\..\\..\\..\\NameList.txt", "w");
				if (fp != NULL) {
					for (int i = 0; i < count; i++)
					{
						fprintf(fp, "%s\n", ListOfNames[i]);
					}
					fclose(fp);
				}
				else {
					printf("Error: Could not open file for writing.\n");
				}
				printf("Name deleted from the array\n");
			}
			else {
				printf("Invalid index. Nothing deleted.\n");
			}
			break;
		case 5:
			if (input == 5) {
				printf("Exited Program!\n");
				exit(0);
			}
			break;
		default:
			printf("Invalid Selection");
			break;
		}
	} while (input < 50);


	return(0);
}